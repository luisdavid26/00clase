"use strict";

/**
 * Apartado 1
 * Realiza los siguientes pasos (muestra por consola el resultado después de aplicar cada uno):
 * - Crea un array llamado "arreglo" con 4 elementos
 * - Concatena 2 elementos más al final y 2 elementos más al principio de ese array
 * - Elimina las posiciones de la 3 a la 5 (ambas incluidas)
 * - Inserta 2 elementos más entre el penúltimo y el último
 * - Muestra el array del paso anterior, pero con los elementos separados por " ==> "
 */

console.log("--------------- APARTADO 1 -----------------");



/**
 * Apartado 2
 * Crea una función que reciba como primer parámetro el nombre de un alumno, seguido
 * de un número indeterminado de notas (usa spread para agruparlas en un array).
 * Utiliza el método reduce para sumar las notas y calcula la media, que deberás mostrar por consola.
 * Posible llamada -> calcularNotas("Pepe", 4.25, 6, 8.5, 9)
 */

console.log('--------------- APARTADO 2 -----------------');


/**
 * Apartado 3
 * Crea un array de cadenas llamado "arr" y ordénalo usando el método sort de mayor a menor longitud .
 * Imprime el array original (antes de ordenarlo) y el resultado
 */

console.log("--------------- APARTADO 3 -----------------");




/**
 * Apartado 4
 * Crea un array de números llamado "arrNum" que contenga numeros de más de una cifra. Mapea 
 * ese array en otro que sea la suma de las cifras de cada número.
 * 
 * No puedes usar bucles.
 * 
 * Pista: Puedes convertir los números a cadena primero y después con Array.from(cadena) la
 * transformas a array de caracteres (que puedes sumar)
 * 
 * Imprime el array original y el resultado
 */

console.log("--------------- APARTADO 4 -----------------");





/**
 * Apartado 5 
 * A partir de la estructura básica de la web de este proyecto debes hacer lo siguiente:
 * 
 * Selecciona mediante JavaScript el elemento div que tiene el id "container" y debes crear 
 * un elemento llamado "el1" que contenga este div.
 * 
 * Selecciona mediante JavaScript el elemento h2 que tiene el texto "Ejercicio bloque 1" y 
 * crea con ello el elemento "el2".
 * 
 * Despues crea un elemento llamado "el3" que contenga un h1 con el 
 * texto "Examen 1".
 * 
 * Por último: borramos y volvemos a añadir el elemento h2 al DIV que lo contiene haciendo:
 * 
 * Primero, borramos el elemento "el2" del elemento "el1"
 * Finalmente volemos a añadir ese elemento "el2" al elemento "el1"
 *  
 */

console.log("--------------- APARTADO 5 -----------------");


