function guardarDatos() {
  
  








  // Validar los campos (puedes agregar lógica de validación aquí)
  
  


  // Guardar los datos en localStorage en formato JSON
  
  
}

function recuperarDatos() {
  // la constante aqui se llamará (formulario)
  
  // la constante para los guardar los datos se llamará (datosGuardados)
  

  // Verificar si hay datos almacenados
  
            // Aqui vas a necesitar una constante para almacenar en memoria los datos que te llegan desde el localStorage, se llamará esta constante (datos)
  
            // Rellenar el formulario con los datos recuperados
            





            
}

function limpiarFormulario() {
  // Aqui va otra constante llamada (formulario)

  // Y con la siguiente orden borras todo el formulario (Es una sola linea y un solo método el usado aquí)
  
}

function borrarAlmacenamiento() {
  
  
  
}
